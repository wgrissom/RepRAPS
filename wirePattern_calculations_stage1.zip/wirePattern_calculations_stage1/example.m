% example for calculating the wire pattern for a 1:1 optimized wilkinson power
% splitter on a RO3006 substrate (copper
% clad=35um,thickness=50mil,Er=6.5)at 7T (298 MHz)

%Files Needed:
%Z_calc.m
%Width_calc.m
%Radius_calc.m
%wirePattern_stage1_calc.m 
%draw.m

ratio = 1; %power ratio (Port 1 / Port 2)
Z0 = 50; %characteristic impedance (ohm)
cu_weight = 35; %thickness of copper clad (um)
thickness = 50; %thickness of dielectric (mil)
Er = 6.5; %relative dielectric constant
frequency = 2.98*10^8; %Larmor frequency (Hz)

[Z_matrix , R] = Z_calc(ratio,Z0); %4x1 matrix of segment impedances and resistor value
Width_matrix = Width_calc(Z_matrix,cu_weight,thickness,Er); %4x1 matrix of trace thickness
[Radii_matrix,tl] = Radius_calc(Width_matrix,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
[rtls] = wirePattern_stage1_calc(Radii_matrix,tl,Width_matrix); %plot point values of optimized power splitter
%the wire pattern can be imported into an EM simulator and then exported as
%a board file
