 % function: Ratio_calc - calculate ratios for the two-stage board
% in1: ratio1 - power split ratio at port 2 (input port is port 1)
% in2: ratio2 - power split ratio at port 3 (input port is port 1)
% in3: ratio3 - power split ratio at port 4 (input port is port 1)
% out1: Ratio_matrix - 3x1 matrix of power splitter ratios of port 2, 3 and 4 [Ratio1 Ratio2 Ratio3]
function Ratio_matrix = Ratio_calc(ratio1,ratio2,ratio3) 
Ratio1_i = ratio1 + ratio2;
Ratio2_i = ratio1 / (ratio1 + ratio2);
Ratio3_i = ratio3 / (1 - ratio1 - ratio2);
Ratio1 = 1/((1/Ratio1_i) - 1);
Ratio2 = 1/((1/Ratio2_i) - 1);
Ratio3 = 1/((1/Ratio3_i) - 1);
if Ratio2 <= Ratio3 || Ratio3 > 100
    Ratio_matrix = [Ratio1, Ratio2, Ratio3];
else
    Ratio_matrix = [Ratio1, Ratio3, Ratio2];
end
end