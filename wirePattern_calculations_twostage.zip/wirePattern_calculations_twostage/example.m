% example for calculating the wire pattern for a two-stage optimized wilkinson power
% splitter on a RO3006 substrate (copper
% clad=35um,thickness=50mil,Er=6.5)at 7T (298 MHz)

%Files Needed:
%Ratio_calc.m
%Z_calc.m
%Width_calc.m
%Radius_calc.m
%Radius_calc_higherRatio.m
%wirePattern_stage1_twoStage_calc.m
%wirePattern_stage2_twoStageL_calc.m
%wirePattern_stage2_twoStageU_calc.m
%wirePattern_stage2_twoStageL_calc_higherRatio.m
%wirePattern_stage2_twoStageU_calc_higherRatio.m
%wirePattern_twoStage_calc.m
%draw.m

ratio1 = 0.5*0.666; %power ratio (Port 1 / Port 2)
ratio2 = 0.5*0.333;
ratio3 = 0.5*0.5;
ratio4 = 1-(ratio1 + ratio2 + ratio3); 
Z0 = 50; %characteristic impedance (ohm)
cu_weight = 35; %thickness of copper clad (um)
thickness = 50; %thickness of dielectric (mil)
Er = 6.5; %relative dielectric constant
frequency = 2.98*10^8; %Larmor frequency (Hz)

[Ratio_matrix] = Ratio_calc(ratio1,ratio2,ratio3);
R_twoStage = [0 0 0];
[Z_matrix_twoStage_1,R_twoStage(1)] = Z_calc(Ratio_matrix(1),Z0); %4x1 matrix of segment impedances and resistor value
[Z_matrix_twoStage_2,R_twoStage(2)] = Z_calc(Ratio_matrix(2),Z0); %4x1 matrix of segment impedances and resistor value
[Z_matrix_twoStage_3,R_twoStage(3)] = Z_calc(Ratio_matrix(3),Z0); %4x1 matrix of segment impedances and resistor value
Width_matrix_twoStage_1 = Width_calc(Z_matrix_twoStage_1,cu_weight,thickness,Er); %4x1 matrix of trace thickness
Width_matrix_twoStage_2 = Width_calc(Z_matrix_twoStage_2,cu_weight,thickness,Er); %4x1 matrix of trace thickness
Width_matrix_twoStage_3 = Width_calc(Z_matrix_twoStage_3,cu_weight,thickness,Er); %4x1 matrix of trace thickness
    if Ratio_matrix(1) <= 2.5 
        [Radii_matrix_twoStage_1,tl] = Radius_calc(Width_matrix_twoStage_1,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    elseif Ratio_matrix(1) <=4.3
        [Radii_matrix_twoStage_1,tl] = Radius_calc_higherRatio(Width_matrix_twoStage_1,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    end
    if Ratio_matrix(2) <= 2.5 
        [Radii_matrix_twoStage_2,tl] = Radius_calc(Width_matrix_twoStage_2,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    elseif Ratio_matrix(2) <=4.3
        [Radii_matrix_twoStage_2,tl] = Radius_calc_higherRatio(Width_matrix_twoStage_2,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    end
    if Ratio_matrix(3) <= 2.5 
        [Radii_matrix_twoStage_3,tl] = Radius_calc(Width_matrix_twoStage_3,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    elseif Ratio_matrix(3) <=4.3
        [Radii_matrix_twoStage_3,tl] = Radius_calc_higherRatio(Width_matrix_twoStage_3,frequency); %4x1 matrix of turn radii for optimized pattern and desired trace length
    end
Radii_matrix = [Radii_matrix_twoStage_1,Radii_matrix_twoStage_2,Radii_matrix_twoStage_3];
Width_matrix = [Width_matrix_twoStage_1,Width_matrix_twoStage_2,Width_matrix_twoStage_3];
[rtls] = wirePattern_twoStage_calc(Radii_matrix,tl,Width_matrix,Ratio_matrix);