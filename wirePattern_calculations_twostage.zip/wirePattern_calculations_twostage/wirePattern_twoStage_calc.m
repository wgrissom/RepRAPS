% function: wirePattern_stage2_twoStageU_calc_higherRatio - plot point values of two-stage optimized power
% splitter 
% in1: Radii_matrix - 12x1 matrix of turn radii of all 12 traces (4 traces*3 power splitters) (mm) [r1 r2 r3 r4 r5 r6 r7 r8 r9 r10 r11 r12]
% in2: Width_matrix - 12x1 matrix of trace thickness of all 12 traces (4 traces*3 power splitters) (mm) [W1 W2 W3 W4 W5 W6 W7 W8 W9 W10 W11 W12]
% in3: Ratio_matrix - 3x1 matrix of power splitter ratios [Ratio1, Ratio2, Ratio3]
% out1: rtls1 - 4x1 matrix of remaining trace lengths of stage 1 power splitter [rtls1 rtl2 rtl3] --> all ~0 (sanity check)
% out2: rtls2 - 4x1 matrix of remaining trace lengths of stage 2 upper power splitter [rtls1 rtl2 rtl3] --> all ~0 (sanity check)
% out3: rtls3 - 4x1 matrix of remaining trace lengths of stage 2 lower power splitter [rtls1 rtl2 rtl3] --> all ~0 (sanity check)

function [rtls1,rtls2,rtls3] = wirePattern_twoStage_calc(Radii_matrix,tl,Width_matrix,Ratio_matrix)
Radii_matrix_1 = [Radii_matrix(1),Radii_matrix(2),Radii_matrix(3),Radii_matrix(4)];
Radii_matrix_2 = [Radii_matrix(5),Radii_matrix(6),Radii_matrix(7),Radii_matrix(8)];
Radii_matrix_3 = [Radii_matrix(9),Radii_matrix(10),Radii_matrix(11),Radii_matrix(12)];
Width_matrix_1 = [Width_matrix(1),Width_matrix(2),Width_matrix(3),Width_matrix(4)];
Width_matrix_2 = [Width_matrix(5),Width_matrix(6),Width_matrix(7),Width_matrix(8)];
Width_matrix_3 = [Width_matrix(9),Width_matrix(10),Width_matrix(11),Width_matrix(12)];
if Ratio_matrix(3) > 100
    [rtls1] = wirePattern_stage1_threeport_twoStage_calc(Radii_matrix_1,tl,Width_matrix_1);
else
    [rtls1] = wirePattern_stage1_twoStage_calc(Radii_matrix_1,tl,Width_matrix_1);
if Ratio_matrix(3) <= 2.5 
    [rtls3] = wirePattern_stage2_twoStageL_calc(Radii_matrix_3,tl,Width_matrix_3); %plot point values of optimized power splitter
elseif Ratio_matrix(2) <=4.3
    [rtls3] = wirePattern_stage2_twoStageL_calc_higherRatio(Radii_matrix_3,tl,Width_matrix_3); %plot point values of optimized power splitter
end
end
if Ratio_matrix(2) <= 2.5 
    [rtls2] = wirePattern_stage2_twoStageU_calc(Radii_matrix_2,tl,Width_matrix_2); %plot point values of optimized power splitter
elseif Ratio_matrix(2) <=4.3
    [rtls2] = wirePattern_stage2_twoStageU_calc_higherRatio(Radii_matrix_2,tl,Width_matrix_2); %plot point values of optimized power splitter
end
end